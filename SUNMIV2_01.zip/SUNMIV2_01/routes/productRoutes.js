const express = require('express');

module.exports = (Product) => {
  const router = express.Router();

  router.post('/add', async (req, res) => {
    const { name, code, quantity } = req.body;
    try {
      const product = await Product.create({ name, code, quantity });
      res.json(product);
    } catch (error) {
      res.status(400).send(error.message);
    }
  });

  router.post('/scan', async (req, res) => {
    const { code } = req.body;
    try {
      const product = await Product.findOne({ where: { code } });
      if (product) {
        res.json(product);
      } else {
        res.status(404).send('Product not found');
      }
    } catch (error) {
      res.status(400).send(error.message);
    }
  });

  router.post('/update', async (req, res) => {
    const { code, quantity } = req.body;
    try {
      const product = await Product.findOne({ where: { code } });
      if (product) {
        product.quantity = quantity;
        await product.save();
        res.json(product);
      } else {
        res.status(404).send('Product not found');
      }
    } catch (error) {
      res.status(400).send(error.message);
    }
  });

  return router;
};
