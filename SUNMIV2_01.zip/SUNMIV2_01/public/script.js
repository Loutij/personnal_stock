const fs = require('fs');
const https = require('https');
const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const { Sequelize, DataTypes } = require('sequelize');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

// Configuration de Sequelize avec SQLite
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'database.sqlite'
});

// Définition du modèle de produit
const Product = sequelize.define('Product', {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  code: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  category: {
    type: DataTypes.STRING,
    allowNull: false
  },
  imageUrl: {
    type: DataTypes.STRING,
    allowNull: true
  }
});

// Définition du modèle de log
const Log = sequelize.define('Log', {
  action: {
    type: DataTypes.STRING,
    allowNull: false
  },
  productCode: {
    type: DataTypes.STRING,
    allowNull: false
  },
  message: {
    type: DataTypes.STRING,
    allowNull: false
  },
  timestamp: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: Sequelize.NOW
  }
});

// Synchronisation des modèles avec la base de données
sequelize.sync({ alter: true });

// Configurer Multer pour gérer les uploads d'images
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'public/uploads/');
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Fonction pour enregistrer un log
const logAction = async (action, productCode, message) => {
  await Log.create({ action, productCode, message });
};

// Route pour ajouter un produit
app.post('/add-product', upload.single('image'), async (req, res) => {
  const { name, code, quantity, category } = req.body;
  const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;
  try {
    const product = await Product.create({ name, code, quantity, category, imageUrl });
    await logAction('ADD', code, `Product ${name} added with quantity ${quantity}`);
    console.log('Product added:', product);
    res.json(product);
  } catch (error) {
    console.error('Error adding product:', error.message);
    res.status(400).send(error.message);
  }
});

// Route pour scanner un produit
app.post('/scan-product', async (req, res) => {
  const { code } = req.body;
  try {
    const product = await Product.findOne({ where: { code } });
    if (product) {
      console.log('Product found:', product);
      res.json(product);
    } else {
      console.log('Product not found with code:', code);
      res.status(404).send('Product not found');
    }
  } catch (error) {
    console.error('Error scanning product:', error.message);
    res.status(400).send(error.message);
  }
});

// Route pour mettre à jour la quantité d'un produit
app.post('/update-quantity', async (req, res) => {
  const { code, quantity } = req.body;
  try {
    const product = await Product.findOne({ where: { code } });
    if (product) {
      product.quantity = quantity;
      await product.save();
      await logAction('UPDATE', code, `Quantity updated to ${quantity} for product ${product.name}`);
      console.log('Quantity updated:', product);
      res.json(product);
    } else {
      console.log('Product not found with code:', code);
      res.status(404).send('Product not found');
    }
  } catch (error) {
    console.error('Error updating quantity:', error.message);
    res.status(400).send(error.message);
  }
});

// Route pour supprimer un produit
app.post('/delete-product', async (req, res) => {
  const { code } = req.body;
  try {
    const product = await Product.findOne({ where: { code } });
    if (product) {
      await product.destroy();
      await logAction('DELETE', code, `Product ${product.name} deleted`);
      console.log('Product deleted:', product);
      res.json({ message: 'Product deleted' });
    } else {
      console.log('Product not found with code:', code);
      res.status(404).send('Product not found');
    }
  } catch (error) {
    console.error('Error deleting product:', error.message);
    res.status(400).send(error.message);
  }
});

// Route pour obtenir l'inventaire
app.get('/get-inventory', async (req, res) => {
  try {
    const products = await Product.findAll();
    res.json(products);
  } catch (error) {
    console.error('Error getting inventory:', error.message);
    res.status(400).send(error.message);
  }
});

// Route pour obtenir les logs
app.get('/get-logs', async (req, res) => {
  try {
    const logs = await Log.findAll();
    res.json(logs);
  } catch (error) {
    console.error('Error getting logs:', error.message);
    res.status(400).send(error.message);
  }
});

// Route pour servir le fichier menu.html à la racine
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'menu.html'));
});

// Charger les certificats SSL
const options = {
  key: fs.readFileSync('localhost-key.pem'),
  cert: fs.readFileSync('localhost.pem')
};

// Démarrer le serveur HTTPS
https.createServer(options, app).listen(3000, () => {
  console.log('Server is running on https://localhost:3000');
});
